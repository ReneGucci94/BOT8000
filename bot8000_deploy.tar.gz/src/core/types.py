from decimal import Decimal

Price = Decimal
Volume = Decimal
Timestamp = int  # Unix timestamp in milliseconds
